package com.lyq.util.hibernate;

import com.lyq.model.Sex;

public class SexType extends EnumType<Sex> {
	public SexType() {
		super(Sex.class);
	}
}
