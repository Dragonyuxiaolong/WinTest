package com.lyq.dao.product;

import com.lyq.dao.BaseDao;
import com.lyq.model.product.ProductCategory;

public interface ProductCategoryDao extends BaseDao<ProductCategory> {

}
